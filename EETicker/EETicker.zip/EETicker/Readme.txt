EETicker

Created by:
http://steamcommunity.com/id/palker
Owynn Kenli

eeticker.psd - PSD file of eeticker
final.png - eeticker layout
esport event ticker new.png - layout base